package Task;

/**
 * Represents a Task with a unique ID, name, and description.
 * Includes validation and truncation rules to ensure data integrity.
 *
 * - Task ID: must be exactly 10 characters (non-null)
 * - Task Name: non-null, non-empty, max 18 characters (truncated if longer)
 * - Task Description: non-null, non-empty, max 50 characters (truncated if longer)
 */
public class Task {
    private String taskID;
    private String taskName;
    private String taskDescription;

    /**
     * Constructs a Task object with validation.
     *
     * @param taskID          Must be exactly 10 characters long
     * @param taskName        Cannot be null/empty; truncated to 18 characters
     * @param taskDescription Cannot be null/empty; truncated to 50 characters
     */
    public Task(String taskID, String taskName, String taskDescription) {
        setTaskID(taskID);
        setTaskName(taskName);
        setTaskDescription(taskDescription);
    }

    // ===== Task ID =====
    public String getTaskID() {
        return taskID;
    }

    public void setTaskID(String taskID) {
        if (taskID == null || taskID.length() != 10) {
            throw new IllegalArgumentException("Task ID must have exactly 10 characters.");
        }
        this.taskID = taskID;
    }

    // ===== Task Name =====
    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        if (taskName == null || taskName.isEmpty()) {
            this.taskName = "InvalidName";
        } else if (taskName.length() > 18) {
            this.taskName = taskName.substring(0, 18); // truncate
        } else {
            this.taskName = taskName;
        }
    }

    // ===== Task Description =====
    public String getTaskDescription() {
        return taskDescription;
    }

    public void setTaskDescription(String taskDescription) {
        if (taskDescription == null || taskDescription.isEmpty()) {
            this.taskDescription = "InvalidDescription";
        } else if (taskDescription.length() > 50) {
            this.taskDescription = taskDescription.substring(0, 50); // truncate
        } else {
            this.taskDescription = taskDescription;
        }
    }
}
