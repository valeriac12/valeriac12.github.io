package Task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for Task class.
 * Validates ID, name, and description rules with algorithmic constraints.
 */
public class TaskTest {

    @Test
    @DisplayName("Valid Task should be created successfully")
    void testValidTask() {
        Task task = new Task("1234567890", "TaskName", "Valid description.");
        assertEquals("1234567890", task.getTaskID());
        assertEquals("TaskName", task.getTaskName());
        assertEquals("Valid description.", task.getTaskDescription());
    }

    @Test
    @DisplayName("Task ID must be exactly 10 characters")
    void testInvalidTaskID() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "TaskName", "Description");
        });
        assertTrue(exception.getMessage().contains("Task ID must have exactly 10 characters."));
    }

    @Test
    @DisplayName("Task name should truncate to 18 characters")
    void testTaskNameTruncation() {
        Task task = new Task("1234567890", "ThisNameIsWayTooLongToBeValid", "Description");
        assertEquals(18, task.getTaskName().length());
    }

    @Test
    @DisplayName("Task description should truncate to 50 characters")
    void testTaskDescriptionTruncation() {
        Task task = new Task("1234567890", "TaskName", "This description is way too long and will be truncated to fit properly.");
        assertEquals(50, task.getTaskDescription().length());
    }

    @Test
    @DisplayName("Null or empty Task name should default to InvalidName")
    void testNullOrEmptyTaskName() {
        Task task1 = new Task("1234567890", null, "Description");
        Task task2 = new Task("1234567890", "", "Description");
        assertEquals("InvalidName", task1.getTaskName());
        assertEquals("InvalidName", task2.getTaskName());
    }

    @Test
    @DisplayName("Null or empty Task description should default to InvalidDescription")
    void testNullOrEmptyTaskDescription() {
        Task task1 = new Task("1234567890", "TaskName", null);
        Task task2 = new Task("1234567890", "TaskName", "");
        assertEquals("InvalidDescription", task1.getTaskDescription());
        assertEquals("InvalidDescription", task2.getTaskDescription());
    }
}
