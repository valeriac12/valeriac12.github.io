package Contact;

import java.util.ArrayList;

/**
 * Service class for managing Contact objects.
 * Provides methods to add, retrieve, update, and delete contacts.
 */
public class ContactService {

    private final ArrayList<Contact> contactList = new ArrayList<>();

    /**
     * Adds a new contact if not a duplicate.
     *
     * @param firstName First name
     * @param lastName  Last name
     * @param number    Phone number
     * @param address   Address
     * @return The generated contact ID
     */
    public String addContact(String firstName, String lastName, String number, String address) {
        Contact contact = new Contact(firstName, lastName, number, address);

        if (contactList.stream().anyMatch(c -> c.getContactID().equals(contact.getContactID()))) {
            throw new IllegalArgumentException("Duplicate Contact ID not allowed");
        }

        contactList.add(contact);
        return contact.getContactID();
    }

    /**
     * Retrieves a contact by ID.
     *
     * @param contactID The contact's unique ID
     * @return Contact object if found, otherwise null
     */
    public Contact getContact(String contactID) {
        return contactList.stream()
                .filter(c -> c.getContactID().equals(contactID))
                .findFirst()
                .orElse(null);
    }

    /**
     * Deletes a contact by ID.
     *
     * @param contactID The ID of the contact to delete
     */
    public void deleteContact(String contactID) {
        contactList.removeIf(c -> c.getContactID().equals(contactID));
    }

    // ===== Update Methods =====

    public void updateFirstName(String contactID, String firstName) {
        Contact contact = getContact(contactID);
        if (contact != null) {
            contact.setFirstName(firstName);
        }
    }

    public void updateLastName(String contactID, String lastName) {
        Contact contact = getContact(contactID);
        if (contact != null) {
            contact.setLastName(lastName);
        }
    }

    public void updateNumber(String contactID, String number) {
        Contact contact = getContact(contactID);
        if (contact != null) {
            contact.setNumber(number);
        }
    }

    public void updateAddress(String contactID, String address) {
        Contact contact = getContact(contactID);
        if (contact != null) {
            contact.setAddress(address);
        }
    }

    /** @return List of all contacts */
    public ArrayList<Contact> getAllContacts() {
        return contactList;
    }
}
