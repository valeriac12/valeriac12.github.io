package Contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for ContactService class.
 */
public class ContactServiceTest {

    @Test
    @DisplayName("Service should add a contact successfully")
    void testAddContact() {
        ContactService service = new ContactService();
        String id = service.addContact("John", "Smith", "1234567890", "123 Main St");
        assertNotNull(service.getContact(id), "Contact was not added correctly.");
    }

    @Test
    @DisplayName("Service should update first name successfully")
    void testUpdateFirstName() {
        ContactService service = new ContactService();
        String id = service.addContact("John", "Smith", "1234567890", "123 Main St");

        service.updateFirstName(id, "Max");
        assertEquals("Max", service.getContact(id).getFirstName(), "First name was not updated.");
    }

    @Test
    @DisplayName("Service should delete contact successfully")
    void testDeleteContact() {
        ContactService service = new ContactService();
        String id = service.addContact("John", "Smith", "1234567890", "123 Main St");

        service.deleteContact(id);
        assertNull(service.getContact(id), "Contact was not deleted.");
    }

    @Test
    @DisplayName("Adding a duplicate contact should throw exception")
    void testDuplicateContactThrowsException() {
        ContactService service = new ContactService();
        String id1 = service.addContact("John", "Smith", "1234567890", "123 Main St");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact("Jane", "Doe", "9876543210", "456 Oak St");
        }, "Duplicate ID was allowed.");
    }
}
