package Appointment;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Date;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for the AppointmentService class.
 * Validates adding, deleting, and preventing duplicates.
 */
class AppointmentServiceTest {

    @Test
    void testAddAppointmentSuccessfully() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);

        service.addAppointment("12345", futureDate, "Test Description");

        assertEquals(1, service.getAppointments().size());
        assertEquals("12345", service.getAppointments().get(0).getAppointmentID());
    }

    @Test
    void testAddDuplicateAppointmentThrowsException() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);

        service.addAppointment("12345", futureDate, "Test Description");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("12345", futureDate, "Duplicate Test");
        });
    }

    @Test
    void testDeleteAppointmentSuccessfully() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);

        service.addAppointment("12345", futureDate, "Test Description");
        service.deleteAppointment("12345");

        assertTrue(service.getAppointments().isEmpty());
    }

    @Test
    void testDeleteNonexistentAppointmentDoesNothing() {
        AppointmentService service = new AppointmentService();

        service.deleteAppointment("NonexistentID");

        assertEquals(0, service.getAppointments().size());
    }
}
