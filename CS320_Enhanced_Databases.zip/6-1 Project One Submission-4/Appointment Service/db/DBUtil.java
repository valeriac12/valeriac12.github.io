package db;

import java.sql.*;

public final class DBUtil {
  private static final String URL  = "jdbc:h2:./cs320db;MODE=MySQL;AUTO_SERVER=TRUE";
  private static final String USER = "sa";
  private static final String PASS = "";

  static {
    try {
      Class.forName("org.h2.Driver");
      try (Connection c = getConnection(); Statement st = c.createStatement()) {
        st.execute("""
          CREATE TABLE IF NOT EXISTS APPOINTMENT (
            id VARCHAR(10) PRIMARY KEY,
            appt_date TIMESTAMP NOT NULL,
            description VARCHAR(50) NOT NULL
          );
        """);

        st.execute("""
          CREATE TABLE IF NOT EXISTS CONTACT (
            id VARCHAR(10) PRIMARY KEY,
            first_name VARCHAR(10) NOT NULL,
            last_name  VARCHAR(10) NOT NULL,
            phone      CHAR(10)    NOT NULL,
            address    VARCHAR(30) NOT NULL
          );
        """);

        st.execute("""
          CREATE TABLE IF NOT EXISTS TASK (
            id VARCHAR(10) PRIMARY KEY,
            name VARCHAR(20) NOT NULL,
            description VARCHAR(50) NOT NULL
          );
        """);
      }
    } catch (Exception e) {
      throw new RuntimeException("Failed to init DB", e);
    }
  }

  public static Connection getConnection() throws SQLException {
    return DriverManager.getConnection(URL, USER, PASS);
  }

  private DBUtil() {}
}
