package dao;

import db.DBUtil;
import Contact.Contact;

import java.sql.*;
import java.util.*;
import java.util.regex.Pattern;

public class ContactDAO {

    private static final Pattern DIGITS10 = Pattern.compile("^\\d{10}$");

    private void validate(Contact c) {
        if (c == null) throw new IllegalArgumentException("Contact is null");
        if (c.getContactID() == null || c.getContactID().length() > 10)
            throw new IllegalArgumentException("ID ≤ 10 chars");
        if (c.getFirstName() == null || c.getFirstName().length() > 10)
            throw new IllegalArgumentException("First name ≤ 10 chars");
        if (c.getLastName() == null || c.getLastName().length() > 10)
            throw new IllegalArgumentException("Last name ≤ 10 chars");
        if (c.getNumber() == null || !DIGITS10.matcher(c.getNumber()).matches())
            throw new IllegalArgumentException("Phone must be exactly 10 digits");
        if (c.getAddress() == null || c.getAddress().length() > 30)
            throw new IllegalArgumentException("Address ≤ 30 chars");
    }

    public boolean insert(Contact c) throws SQLException {
        validate(c);
        String sql = "INSERT INTO CONTACT(id, first_name, last_name, phone, address) VALUES (?,?,?,?,?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getContactID());
            ps.setString(2, c.getFirstName());
            ps.setString(3, c.getLastName());
            ps.setString(4, c.getNumber());
            ps.setString(5, c.getAddress());
            return ps.executeUpdate() == 1;
        }
    }

    public Optional<Contact> findById(String id) throws SQLException {
        String sql = "SELECT id, first_name, last_name, phone, address FROM CONTACT WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return Optional.empty();
                return Optional.of(new Contact(
                        rs.getString("id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("phone"),
                        rs.getString("address")));
            }
        }
    }

    public List<Contact> findAll() throws SQLException {
        String sql = "SELECT id, first_name, last_name, phone, address FROM CONTACT ORDER BY last_name, first_name";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            List<Contact> out = new ArrayList<>();
            while (rs.next()) {
                out.add(new Contact(
                        rs.getString("id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("phone"),
                        rs.getString("address")));
            }
            return out;
        }
    }

    public boolean update(Contact c) throws SQLException {
        validate(c);
        String sql = "UPDATE CONTACT SET first_name=?, last_name=?, phone=?, address=? WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getFirstName());
            ps.setString(2, c.getLastName());
            ps.setString(3, c.getNumber());
            ps.setString(4, c.getAddress());
            ps.setString(5, c.getContactID());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean delete(String id) throws SQLException {
        String sql = "DELETE FROM CONTACT WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    public void deleteAll() throws SQLException {
        try (Connection conn = DBUtil.getConnection();
             Statement st = conn.createStatement()) {
            st.executeUpdate("DELETE FROM CONTACT");
        }
    }
}
