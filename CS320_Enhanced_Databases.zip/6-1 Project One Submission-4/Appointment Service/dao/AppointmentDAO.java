package dao;

import db.DBUtil;
import Appointment.Appointment;

import java.sql.*;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class AppointmentDAO {

    private void validate(Appointment a) {
        if (a == null) throw new IllegalArgumentException("Appointment is null");
        if (a.getAppointmentID() == null || a.getAppointmentID().length() > 10)
            throw new IllegalArgumentException("ID must be non-null and ≤ 10 chars");
        if (a.getDescription() == null || a.getDescription().length() > 50)
            throw new IllegalArgumentException("Description must be non-null and ≤ 50 chars");

        Instant now = Instant.now();
        Instant max = now.plus(50, ChronoUnit.DAYS);
        Instant when = a.getAppointmentDate().toInstant();
        if (!when.isAfter(now) || when.isAfter(max))
            throw new IllegalArgumentException("Date must be in the future and ≤ 50 years");
    }

    public boolean insert(Appointment a) throws SQLException {
        validate(a);
        String sql = "INSERT INTO APPOINTMENT(id, appt_date, description) VALUES (?,?,?)";
        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, a.getAppointmentID());
            ps.setTimestamp(2, Timestamp.from(a.getAppointmentDate().toInstant()));
            ps.setString(3, a.getDescription());
            return ps.executeUpdate() == 1;
        }
    }

    public Optional<Appointment> findById(String id) throws SQLException {
        String sql = "SELECT id, appt_date, description FROM APPOINTMENT WHERE id = ?";
        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return Optional.empty();
                return Optional.of(new Appointment(
                        rs.getString("id"),
                        new java.util.Date(rs.getTimestamp("appt_date").getTime()),
                        rs.getString("description")));
            }
        }
    }

    public List<Appointment> findAll() throws SQLException {
        String sql = "SELECT id, appt_date, description FROM APPOINTMENT ORDER BY appt_date";
        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            List<Appointment> out = new ArrayList<>();
            while (rs.next()) {
                out.add(new Appointment(
                        rs.getString("id"),
                        new java.util.Date(rs.getTimestamp("appt_date").getTime()),
                        rs.getString("description")));
            }
            return out;
        }
    }

    public boolean update(Appointment a) throws SQLException {
        validate(a);
        String sql = "UPDATE APPOINTMENT SET appt_date = ?, description = ? WHERE id = ?";
        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setTimestamp(1, Timestamp.from(a.getAppointmentDate().toInstant()));
            ps.setString(2, a.getDescription());
            ps.setString(3, a.getAppointmentID());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean delete(String id) throws SQLException {
        String sql = "DELETE FROM APPOINTMENT WHERE id = ?";
        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    // For cleaning table between tests
    public void deleteAll() throws SQLException {
        try (Connection c = DBUtil.getConnection(); Statement st = c.createStatement()) {
            st.executeUpdate("DELETE FROM APPOINTMENT");
        }
    }
}
