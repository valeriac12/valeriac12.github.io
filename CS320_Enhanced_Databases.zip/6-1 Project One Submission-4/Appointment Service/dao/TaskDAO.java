package dao;

import db.DBUtil;
import Task.Task;

import java.sql.*;
import java.util.*;

public class TaskDAO {

    private void validate(Task t) {
        if (t == null) throw new IllegalArgumentException("Task is null");
        if (t.getTaskID() == null || t.getTaskID().length() > 10)
            throw new IllegalArgumentException("ID ≤ 10 chars");
        if (t.getTaskName() == null || t.getTaskName().length() > 20)
            throw new IllegalArgumentException("Name ≤ 20 chars");
        if (t.getTaskDescription() == null || t.getTaskDescription().length() > 50)
            throw new IllegalArgumentException("Description ≤ 50 chars");
    }

    public boolean insert(Task t) throws SQLException {
        validate(t);
        String sql = "INSERT INTO TASK(id, name, description) VALUES (?,?,?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, t.getTaskID());
            ps.setString(2, t.getTaskName());
            ps.setString(3, t.getTaskDescription());
            return ps.executeUpdate() == 1;
        }
    }

    public Optional<Task> findById(String id) throws SQLException {
        String sql = "SELECT id, name, description FROM TASK WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return Optional.empty();
                return Optional.of(new Task(
                        rs.getString("id"),
                        rs.getString("name"),
                        rs.getString("description")));
            }
        }
    }

    public List<Task> findAll() throws SQLException {
        String sql = "SELECT id, name, description FROM TASK ORDER BY name";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            List<Task> out = new ArrayList<>();
            while (rs.next()) {
                out.add(new Task(
                        rs.getString("id"),
                        rs.getString("name"),
                        rs.getString("description")));
            }
            return out;
        }
    }

    public boolean update(Task t) throws SQLException {
        validate(t);
        String sql = "UPDATE TASK SET name=?, description=? WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, t.getTaskName());
            ps.setString(2, t.getTaskDescription());
            ps.setString(3, t.getTaskID());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean delete(String id) throws SQLException {
        String sql = "DELETE FROM TASK WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    public void deleteAll() throws SQLException {
        try (Connection conn = DBUtil.getConnection();
             Statement st = conn.createStatement()) {
            st.executeUpdate("DELETE FROM TASK");
        }
    }
}
