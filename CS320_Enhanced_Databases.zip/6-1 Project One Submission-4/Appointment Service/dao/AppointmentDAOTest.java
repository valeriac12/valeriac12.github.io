package dao;

import dao.AppointmentDAO;
import Appointment.Appointment;
import org.junit.jupiter.api.*;

import java.sql.SQLException;
import java.time.Instant;
import java.util.Date;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentDAOTest {

    private AppointmentDAO dao;

    @BeforeEach
    void setup() throws SQLException {
        dao = new AppointmentDAO();
        dao.deleteAll(); 
    }

    @Test
    void testInsertAndFind() throws Exception {
        Date apptDate = Date.from(Instant.now().plusSeconds(3600)); 
        Appointment appt = new Appointment("A100", apptDate, "Dentist visit");

        assertTrue(dao.insert(appt), "Insert should return true");

        Optional<Appointment> found = dao.findById("A100");
        assertTrue(found.isPresent(), "Record should exist after insert");
        assertEquals("Dentist visit", found.get().getDescription());
    }

    @Test
    void testUpdateAppointment() throws Exception {
        Date apptDate = Date.from(Instant.now().plusSeconds(3600));
        Appointment appt = new Appointment("A200", apptDate, "Initial Description");
        dao.insert(appt);

        Appointment updated = new Appointment("A200", Date.from(Instant.now().plusSeconds(7200)), "Updated Description");
        assertTrue(dao.update(updated));

        Optional<Appointment> found = dao.findById("A200");
        assertTrue(found.isPresent());
        assertEquals("Updated Description", found.get().getDescription());
    }

    @Test
    void testDeleteAppointment() throws Exception {
        Date apptDate = Date.from(Instant.now().plusSeconds(3600));
        Appointment appt = new Appointment("A300", apptDate, "For deletion");
        dao.insert(appt);

        assertTrue(dao.delete("A300"));
        assertFalse(dao.findById("A300").isPresent());
    }
}
