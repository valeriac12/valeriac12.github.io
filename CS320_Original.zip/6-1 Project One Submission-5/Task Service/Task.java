package Task;

public class Task {
    private String taskID;
    private String taskName;
    private String taskDescription;

    public Task(String taskID, String taskName, String taskDescription) {
        setTaskID(taskID);
        setTaskName(taskName);
        setTaskDescription(taskDescription);
    }

    public String getTaskID() {
        return taskID;
    }

    public void setTaskID(String taskID) {
        if (taskID == null || taskID.length() != 10) {
            throw new IllegalArgumentException("Task ID must have exactly 10 characters.");
        }
        this.taskID = taskID;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        if (taskName == null || taskName.isEmpty()) {
            this.taskName = "InvalidName";
        } else if (taskName.length() > 20) {
            this.taskName = taskName.substring(0, 20); // Truncate if too long
        } else {
            this.taskName = taskName;
        }
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public void setTaskDescription(String taskDescription) {
        if (taskDescription == null || taskDescription.isEmpty()) {
            this.taskDescription = "InvalidDescription";
        } else if (taskDescription.length() > 50) {
            this.taskDescription = taskDescription.substring(0, 50); // Truncate if too long
        } else {
            this.taskDescription = taskDescription;
        }
    }
}
