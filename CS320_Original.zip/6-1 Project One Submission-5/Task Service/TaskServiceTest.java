package Test;

import org.junit.jupiter.api.Test;

import Task.Task;
import Task.TaskService;

import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    @Test
    public void testAddTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("1234567890", "TaskName", "Description");
        taskService.addTask(task);
        assertEquals(task, taskService.getTask("1234567890"));
    }

    @Test
    public void testAddDuplicateTaskID() {
        TaskService taskService = new TaskService();
        Task task1 = new Task("1234567890", "Task1", "Description1");
        Task task2 = new Task("1234567890", "Task2", "Description2");

        taskService.addTask(task1);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(task2);
        });

        assertTrue(exception.getMessage().contains("Task ID must be unique."));
    }

    @Test
    public void testUpdateTaskName() {
        TaskService taskService = new TaskService();
        Task task = new Task("1234567890", "OldName", "Description");
        taskService.addTask(task);

        taskService.updateTaskName("1234567890", "NewName");
        assertEquals("NewName", taskService.getTask("1234567890").getTaskName());
    }

    @Test
    public void testDeleteTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("1234567890", "TaskName", "Description");
        taskService.addTask(task);

        taskService.deleteTask("1234567890");
        assertNull(taskService.getTask("1234567890"));
    }
}