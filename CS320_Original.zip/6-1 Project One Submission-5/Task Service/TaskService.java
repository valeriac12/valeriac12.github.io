package Task;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskID())) {
            throw new IllegalArgumentException("Task ID must be unique.");
        }
        tasks.put(task.getTaskID(), task);
    }

    public Task getTask(String taskID) {
        return tasks.get(taskID);
    }

    public void deleteTask(String taskID) {
        tasks.remove(taskID);
    }

    public void updateTaskName(String taskID, String newName) {
        Task task = tasks.get(taskID);
        if (task != null) {
            task.setTaskName(newName);
        }
    }

    public void updateTaskDescription(String taskID, String newDescription) {
        Task task = tasks.get(taskID);
        if (task != null) {
            task.setTaskDescription(newDescription);
        }
    }
}
