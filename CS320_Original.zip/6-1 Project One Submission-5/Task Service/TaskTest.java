package Test;

import org.junit.jupiter.api.Test;

import Task.Task;

import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testValidTask() {
        Task task = new Task("1234567890", "TaskName", "This is a valid task description.");
        assertEquals("1234567890", task.getTaskID());
        assertEquals("TaskName", task.getTaskName());
        assertEquals("This is a valid task description.", task.getTaskDescription());
    }

    @Test
    public void testInvalidTaskID() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "TaskName", "Description");
        });
        assertTrue(exception.getMessage().contains("Task ID must have exactly 10 characters."));
    }

    @Test
    public void testTaskNameTruncation() {
        Task task = new Task("1234567890", "ThisNameIsWayTooLongToBeValid", "Description");
        assertEquals("ThisNameIsWayTooLon", task.getTaskName());
    }

    @Test
    public void testTaskDescriptionTruncation() {
        Task task = new Task("1234567890", "TaskName", "This description is way too long and will be truncated to fit.");
        assertEquals("This description is way too long and will be trunca", task.getTaskDescription());
    }
}
