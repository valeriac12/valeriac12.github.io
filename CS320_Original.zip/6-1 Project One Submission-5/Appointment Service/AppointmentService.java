package Appointment;

import java.util.ArrayList;
import java.util.List;

public class AppointmentService {
    private final List<Appointment> appointments = new ArrayList<>();

    // Add a new appointment
    public void addAppointment(String appointmentID, java.util.Date futureDate, String description) {
        Appointment newAppointment = new Appointment(appointmentID, futureDate, description);
        appointments.add(newAppointment);
    }

    // Delete an appointment by ID
    public void deleteAppointment(String appointmentID) {
        appointments.removeIf(appointment -> appointment.getAppointmentID().equals(appointmentID));
    }

    // Get all appointments (optional for debugging)
    public List<Appointment> getAppointments() {
        return appointments;
    }
}


