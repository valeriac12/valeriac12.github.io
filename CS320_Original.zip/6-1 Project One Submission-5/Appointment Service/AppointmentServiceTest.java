package Test;

import Appointment.AppointmentService;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class AppointmentServiceTest {

    @Test
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);

        service.addAppointment("12345", futureDate, "Test Description");
        assertEquals(1, service.getAppointments().size());
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 100000);

        service.addAppointment("12345", futureDate, "Test Description");
        service.deleteAppointment("12345");

        assertTrue(service.getAppointments().isEmpty());
    }

    @Test
    void testDeleteNonexistentAppointment() {
        AppointmentService service = new AppointmentService();
        service.deleteAppointment("NonexistentID");

        assertEquals(0, service.getAppointments().size());
    }
}