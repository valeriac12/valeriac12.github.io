package Test;

import Appointment.Appointment;

import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class AppointmentTest {

    @Test
    void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("12345", futureDate, "Test Description");
        assertEquals("12345", appointment.getAppointmentID());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Test Description", appointment.getDescription());
    }

    @Test
    void testInvalidAppointmentID() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", new Date(), "Description");
        });
    }

    @Test
    void testInvalidAppointmentDate() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", new Date(System.currentTimeMillis() - 100000), "Description");
        });
    }

    @Test
    void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", new Date(), new String(new char[51]).replace("\0", "A"));
        });
    }
}

