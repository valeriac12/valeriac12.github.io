// Valeria Carvajal
// 12/01/2024
// CS- 320
package Appointment;

import java.util.Date;

public class Appointment {
    private final String appointmentID;
    private final Date appointmentDate;
    private final String description;

    // Constructor
    public Appointment(String appointmentID, Date appointmentDate, String description) {
        // Appointment ID Validation
        if (appointmentID == null || appointmentID.length() > 10) {
            throw new IllegalArgumentException("Invalid Appointment ID");
        }
        this.appointmentID = appointmentID;

        // Appointment Date Validation
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid Appointment Date");
        }
        this.appointmentDate = appointmentDate;

        // Description Validation
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid Description");
        }
        this.description = description;
    }

    // Getters
    public String getAppointmentID() {
        return appointmentID;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }
}
