package Test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;

import static org.junit.jupiter.api.Assertions.*;

import Contact.Contact;
import Contact.ContactService;

@TestMethodOrder(OrderAnnotation.class)
public class ContactServiceTest {

    ContactService service = new ContactService();

    @Test
    @DisplayName("Test to Update First Name.")
    @Order(1)
    void testUpdateFirstName() {
        
        String contactId = service.addContact("Jackson", "Aloi", "9876543210", "456 Oak Street");
        service.updateFirstName(contactId, "Maximus"); // Update first name to Maximus
        assertEquals("Maximus", service.getContact(contactId).getFirstName(), "First name was not updated.");
    }

    @Test
    @DisplayName("Test to Update Last Name.")
    @Order(2)
    void testUpdateLastName() {
      
        String contactId = service.addContact("Jackson", "Aloi", "9876543210", "456 Oak Street");
        service.updateLastName(contactId, "Shirley"); // Update last name to Shirley
        assertEquals("Shirley", service.getContact(contactId).getLastName(), "Last name was not updated.");
    }

    @Test
    @DisplayName("Test to ensure that service correctly deletes contacts.")
    @Order(3)
    void testDeleteContact() {
        
        String contactId = service.addContact("Jackson", "Aloi", "9876543210", "456 Oak Street");
        service.deleteContact(contactId);
        assertNull(service.getContact(contactId), "The contact was not deleted.");
    }

    @Test
    @DisplayName("Test to ensure that service can add a contact.")
    @Order(4)
    void testAddContact() {
        
        String contactId = service.addContact("Jackson", "Aloi", "9876543210", "456 Oak Street");
        assertNotNull(service.getContact(contactId), "Contact was not added correctly.");
    }
}
