package Contact;

import java.util.ArrayList;

public class ContactService {
	
	/// ArrayList to store Contact objects
    public final ArrayList<Contact> contactList = new ArrayList<>();

    // Display all contacts (for testing/debugging)
    public void displayContactList() {
        for (Contact contact : contactList) {
            System.out.println("Contact ID: " + contact.getContactID());
            System.out.println("First Name: " + contact.getFirstName());
            System.out.println("Last Name: " + contact.getLastName());
            System.out.println("Phone Number: " + contact.getNumber());
            System.out.println("Address: " + contact.getAddress());
            System.out.println();
        }
    }

    // Add a new contact
    public String addContact(String firstName, String lastName, String number, String address) {
        Contact contact = new Contact(firstName, lastName, number, address);
        contactList.add(contact);
        return contact.getContactID(); // Return the contact's ID
    }

    // Get a contact by ID
    public Contact getContact(String contactID) {
        for (Contact contact : contactList) {
            if (contact.getContactID().equals(contactID)) {
                return contact;
            }
        }
        System.out.println("Contact ID not found.");
        return null; // Return null to indicate no contact found
    }

    // Delete a contact by ID
    public void deleteContact(String contactID) {
        Contact contact = getContact(contactID); 
        if (contact != null) {
            contactList.remove(contact);
        } else {
            System.out.println("Contact ID not found.");
        }
    }

    // Update a contact's first name by ID
    public void updateFirstName(String contactID, String firstName) {
        Contact contact = getContact(contactID);
        if (contact != null) {
            contact.setFirstName(firstName);
        }
    }

    // Update a contact's last name by ID
    public void updateLastName(String contactID, String lastName) {
        Contact contact = getContact(contactID);
        if (contact != null) {
            contact.setLastName(lastName);
        }
    }

    // Update a contact's phone number by ID
    public void updateNumber(String contactID, String number) {
        Contact contact = getContact(contactID);
        if (contact != null) {
            contact.setNumber(number);
        }
    }

    // Update a contact's address by ID
    public void updateAddress(String contactID, String address) {
        Contact contact = getContact(contactID);
        if (contact != null) {
            contact.setAddress(address);
        }
    }
}
