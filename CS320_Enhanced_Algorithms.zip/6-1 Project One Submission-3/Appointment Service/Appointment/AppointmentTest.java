package Appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Appointment class.
 * Validates constructor behavior and input validation rules.
 */
class AppointmentTest {

    @Test
    @DisplayName("Valid appointment should be created")
    void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("12345", futureDate, "Test Description");

        assertEquals("12345", appointment.getAppointmentID());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Test Description", appointment.getDescription());
    }

    @Test
    @DisplayName("Appointment ID longer than 10 chars should throw")
    void testInvalidAppointmentID() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", new Date(System.currentTimeMillis() + 100000), "Description");
        });
    }

    @Test
    @DisplayName("Appointment date in the past should throw")
    void testInvalidAppointmentDateInPast() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", new Date(System.currentTimeMillis() - 100000), "Description");
        });
    }

    @Test
    @DisplayName("Appointment date more than 50 years in future should throw")
    void testInvalidAppointmentDateTooFarInFuture() {
        long fiftyOneYearsMillis = 1000L * 60 * 60 * 24 * 365 * 51;
        Date tooFar = new Date(System.currentTimeMillis() + fiftyOneYearsMillis);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", tooFar, "Future too far");
        });
    }

    @Test
    @DisplayName("Description longer than 50 chars should throw")
    void testInvalidDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", new Date(System.currentTimeMillis() + 100000),
                    new String(new char[51]).replace("\0", "A"));
        });
    }
}
