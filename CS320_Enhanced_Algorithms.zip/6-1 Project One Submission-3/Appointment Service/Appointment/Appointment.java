// Valeria Carvajal
// 12/01/2024
// CS-320

package Appointment;

import java.util.Date;

/**
 * Represents an Appointment with a unique ID, scheduled date, and description.
 * Validation rules:
 * - Appointment ID: non-null, <= 10 characters
 * - Appointment Date: must be in the future but not more than 50 years ahead
 * - Description: non-null, <= 50 characters
 */
public class Appointment {
    private final String appointmentID;
    private final Date appointmentDate;
    private final String description;

    public Appointment(String appointmentID, Date appointmentDate, String description) {
        // ===== Appointment ID Validation =====
        if (appointmentID == null || appointmentID.length() > 10) {
            throw new IllegalArgumentException("Invalid Appointment ID");
        }
        this.appointmentID = appointmentID;

        // ===== Appointment Date Validation =====
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid Appointment Date: must be in the future");
        }
        long fiftyYearsInMillis = 1000L * 60 * 60 * 24 * 365 * 50;
        if (appointmentDate.after(new Date(System.currentTimeMillis() + fiftyYearsInMillis))) {
            throw new IllegalArgumentException("Invalid Appointment Date: cannot exceed 50 years in future");
        }
        this.appointmentDate = appointmentDate;

        // ===== Description Validation =====
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid Description");
        }
        this.description = description;
    }

    public String getAppointmentID() {
        return appointmentID;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }
}
