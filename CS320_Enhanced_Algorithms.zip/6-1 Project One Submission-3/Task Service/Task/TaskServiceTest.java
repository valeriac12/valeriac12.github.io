package Task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for TaskService.
 * Covers add, duplicate prevention, updates, delete, and basic counts.
 */
public class TaskServiceTest {

    @Test
    @DisplayName("Task should be added and retrievable by ID")
    void testAddTask() {
        TaskService svc = new TaskService();
        Task t = new Task("1234567890", "TaskName", "Description");
        svc.addTask(t);

        assertEquals(t, svc.getTask("1234567890"));
        assertEquals(1, svc.getTaskCount());
    }

    @Test
    @DisplayName("Adding a task with duplicate ID should throw")
    void testAddDuplicateTaskIdThrows() {
        TaskService svc = new TaskService();
        Task t1 = new Task("1234567890", "Alpha", "Desc1");
        Task t2 = new Task("1234567890", "Beta", "Desc2");

        svc.addTask(t1);
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> svc.addTask(t2));
        assertTrue(ex.getMessage().contains("unique"));
        assertEquals(1, svc.getTaskCount());
    }

    @Test
    @DisplayName("Update task name uses Task validation (truncate/invalid handling)")
    void testUpdateTaskName() {
        TaskService svc = new TaskService();
        Task t = new Task("1234567890", "OldName", "Description");
        svc.addTask(t);

        svc.updateTaskName("1234567890", "ThisNameIsWayTooLongToBeValid");
        assertEquals(18, svc.getTask("1234567890").getTaskName().length());
    }

    @Test
    @DisplayName("Update task description uses Task validation (truncate/invalid handling)")
    void testUpdateTaskDescription() {
        TaskService svc = new TaskService();
        Task t = new Task("1234567890", "TaskName", "OldDescription");
        svc.addTask(t);

        svc.updateTaskDescription("1234567890", "This description is way too long and will be truncated to fit properly.");
        assertEquals(50, svc.getTask("1234567890").getTaskDescription().length());
    }

    @Test
    @DisplayName("Delete task removes it from the service")
    void testDeleteTask() {
        TaskService svc = new TaskService();
        Task t = new Task("1234567890", "TaskName", "Description");
        svc.addTask(t);

        svc.deleteTask("1234567890");
        assertNull(svc.getTask("1234567890"));
        assertEquals(0, svc.getTaskCount());
    }

    @Test
    @DisplayName("Updating a non-existent task should be a no-op (no exception)")
    void testUpdateNonexistentIsNoOp() {
        TaskService svc = new TaskService();
        // No tasks added
        assertDoesNotThrow(() -> {
            svc.updateTaskName("DOESNOTEX", "NewName");
            svc.updateTaskDescription("DOESNOTEX", "NewDesc");
        });
        assertEquals(0, svc.getTaskCount());
    }
}
