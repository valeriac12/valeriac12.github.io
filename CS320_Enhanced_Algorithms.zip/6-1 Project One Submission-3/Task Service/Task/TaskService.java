package Task;

import java.util.HashMap;
import java.util.Map;

/**
 * Service class for managing Task objects.
 * Provides methods to add, retrieve, update, and delete tasks.
 */
public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    /**
     * Adds a task if the ID is unique.
     *
     * @param task The Task object to add
     */
    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskID())) {
            throw new IllegalArgumentException("Task ID must be unique.");
        }
        tasks.put(task.getTaskID(), task);
    }

    /**
     * Retrieves a task by ID.
     *
     * @param taskID The unique ID of the task
     * @return The Task object or null if not found
     */
    public Task getTask(String taskID) {
        return tasks.get(taskID);
    }

    /**
     * Deletes a task by ID.
     *
     * @param taskID The ID of the task to delete
     */
    public void deleteTask(String taskID) {
        tasks.remove(taskID);
    }

    public void updateTaskName(String taskID, String newName) {
        Task task = tasks.get(taskID);
        if (task != null) {
            task.setTaskName(newName);
        }
    }

    public void updateTaskDescription(String taskID, String newDescription) {
        Task task = tasks.get(taskID);
        if (task != null) {
            task.setTaskDescription(newDescription);
        }
    }

    /** @return total number of tasks */
    public int getTaskCount() {
        return tasks.size();
    }
}
