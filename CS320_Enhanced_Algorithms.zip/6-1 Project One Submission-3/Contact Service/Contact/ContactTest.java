package Contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Contact class.
 */
public class ContactTest {

    @Test
    @DisplayName("Generated Contact ID should be non-null")
    void testContactIdGenerated() {
        Contact c = new Contact("First", "Last", "1234567890", "123 Main St");
        assertNotNull(c.getContactID());
    }

    @Test
    @DisplayName("First/Last name should truncate to 10 characters")
    void testNameTruncation() {
        Contact c = new Contact("AlexanderTheGreat", "JohnsonJohnson", "1234567890", "123 Main St");
        assertEquals(10, c.getFirstName().length());
        assertEquals(10, c.getLastName().length());
    }

    @Test
    @DisplayName("Address should truncate to 30 characters")
    void testAddressTruncates() {
        String longAddr = "123456789012345678901234567890EXTRA";
        Contact c = new Contact("First", "Last", "1234567890", longAddr);
        assertEquals(30, c.getAddress().length());
    }

    @Test
    @DisplayName("Invalid phone number (wrong length) defaults to 5555555555")
    void testPhoneNumberInvalidLengthDefaults() {
        Contact c = new Contact("First", "Last", "123", "123 Main St");
        assertEquals("5555555555", c.getNumber());
    }

    @Test
    @DisplayName("Invalid phone number (non-digits) defaults to 5555555555")
    void testPhoneNumberNonDigitsDefaults() {
        Contact c = new Contact("First", "Last", "12345abcde", "123 Main St");
        assertEquals("5555555555", c.getNumber());
    }

    @Test
    @DisplayName("Valid phone number (10 digits) is accepted")
    void testPhoneNumberValid() {
        Contact c = new Contact("First", "Last", "2035550123", "123 Main St");
        assertEquals("2035550123", c.getNumber());
    }

    @Test
    @DisplayName("Null fields default to safe values")
    void testNullDefaults() {
        Contact c = new Contact(null, null, null, null);
        assertEquals("NULL", c.getFirstName());
        assertEquals("NULL", c.getLastName());
        assertEquals("5555555555", c.getNumber());
        assertEquals("NULL", c.getAddress());
    }
}
