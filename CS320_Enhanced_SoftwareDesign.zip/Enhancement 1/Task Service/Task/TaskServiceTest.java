package Task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for TaskService class.
 */
public class TaskServiceTest {

    @Test
    @DisplayName("Task should be added successfully")
    public void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "TaskName", "Description");
        service.addTask(task);

        assertEquals(task, service.getTask("1234567890"));
    }

    @Test
    @DisplayName("Adding duplicate Task ID should throw exception")
    public void testAddDuplicateTaskID() {
        TaskService service = new TaskService();
        Task task1 = new Task("1234567890", "Task1", "Description1");
        Task task2 = new Task("1234567890", "Task2", "Description2");

        service.addTask(task1);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });

        assertTrue(exception.getMessage().contains("Task ID must be unique."));
    }

    @Test
    @DisplayName("Task name should be updated successfully")
    public void testUpdateTaskName() {
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "OldName", "Description");
        service.addTask(task);

        service.updateTaskName("1234567890", "NewName");
        assertEquals("NewName", service.getTask("1234567890").getTaskName());
    }

    @Test
    @DisplayName("Task should be deleted successfully")
    public void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("1234567890", "TaskName", "Description");
        service.addTask(task);

        service.deleteTask("1234567890");
        assertNull(service.getTask("1234567890"));
    }
}
