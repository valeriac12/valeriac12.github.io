package Task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Task class.
 * Validates task ID, name, and description rules.
 */
public class TaskTest {

    @Test
    @DisplayName("Valid task should be created successfully")
    public void testValidTask() {
        Task task = new Task("1234567890", "TaskName", "Valid description.");
        assertEquals("1234567890", task.getTaskID());
        assertEquals("TaskName", task.getTaskName());
        assertEquals("Valid description.", task.getTaskDescription());
    }

    @Test
    @DisplayName("Task ID must be exactly 10 characters")
    public void testInvalidTaskID() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "TaskName", "Description");
        });
        assertTrue(exception.getMessage().contains("Task ID must have exactly 10 characters."));
    }

    @Test
    @DisplayName("Task name should be truncated to 18 characters")
    public void testTaskNameTruncation() {
        Task task = new Task("1234567890", "ThisNameIsWayTooLongToBeValid", "Description");
        assertEquals(18, task.getTaskName().length());
    }

    @Test
    @DisplayName("Task description should be truncated to 50 characters")
    public void testTaskDescriptionTruncation() {
        Task task = new Task("1234567890", "TaskName", "This description is way too long and will be truncated to fit properly.");
        assertEquals(50, task.getTaskDescription().length());
    }
}
