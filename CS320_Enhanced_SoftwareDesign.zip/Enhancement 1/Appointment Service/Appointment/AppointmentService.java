package Appointment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Service class for managing Appointments.
 * Provides functionality to add and delete appointments.
 */
public class AppointmentService {
    private final List<Appointment> appointments = new ArrayList<>();

    /**
     * Adds a new appointment if the ID is not a duplicate.
     *
     * @param appointmentID Unique appointment ID
     * @param futureDate    Appointment date (must be in the future)
     * @param description   Appointment description
     */
    public void addAppointment(String appointmentID, Date futureDate, String description) {
        if (appointments.stream().anyMatch(a -> a.getAppointmentID().equals(appointmentID))) {
            throw new IllegalArgumentException("Duplicate Appointment ID not allowed");
        }
        appointments.add(new Appointment(appointmentID, futureDate, description));
    }

    /**
     * Deletes an appointment by ID.
     *
     * @param appointmentID The ID of the appointment to remove
     */
    public void deleteAppointment(String appointmentID) {
        appointments.removeIf(appointment -> appointment.getAppointmentID().equals(appointmentID));
    }

    /**
     * Retrieves all appointments.
     *
     * @return list of appointments
     */
    public List<Appointment> getAppointments() {
        return appointments;
    }
}
