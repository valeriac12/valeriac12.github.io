// Valeria Carvajal
// 12/01/2024
// CS-320
package Appointment;

import java.util.Date;

/**
 * Represents an Appointment with ID, date, and description.
 * Validates inputs to ensure data integrity and business rules are followed.
 */
public class Appointment {
    private final String appointmentID;
    private final Date appointmentDate;
    private final String description;

    /**
     * Constructs a new Appointment with validation rules.
     *
     * @param appointmentID  Unique ID for the appointment (max length 10).
     * @param appointmentDate Must not be null and cannot be in the past.
     * @param description    Brief description (max length 50).
     */
    public Appointment(String appointmentID, Date appointmentDate, String description) {
        if (appointmentID == null || appointmentID.length() > 10) {
            throw new IllegalArgumentException("Invalid Appointment ID");
        }
        this.appointmentID = appointmentID;

        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid Appointment Date");
        }
        this.appointmentDate = appointmentDate;

        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid Description");
        }
        this.description = description;
    }

    /** @return appointment ID */
    public String getAppointmentID() {
        return appointmentID;
    }

    /** @return appointment date */
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    /** @return appointment description */
    public String getDescription() {
        return description;
    }
}
