package Contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Contact class.
 * Validates ID generation, field constraints, and null handling.
 */
public class ContactTest {

    @Test
    @DisplayName("Generated Contact ID should not exceed 10 characters")
    void testContactIDLength() {
        Contact contact = new Contact("First", "Last", "1234567890", "Address");
        assertTrue(contact.getContactID().length() <= 10, "Contact ID exceeded length.");
    }

    @Test
    @DisplayName("First Name should be trimmed to 10 characters")
    void testFirstNameTrimmed() {
        Contact contact = new Contact("OllyOllyOxenFree", "Last", "1234567890", "Address");
        assertEquals(10, contact.getFirstName().length(), "First Name not trimmed properly.");
    }

    @Test
    @DisplayName("Last Name should be trimmed to 10 characters")
    void testLastNameTrimmed() {
        Contact contact = new Contact("First", "OllyOllyOxenFree", "1234567890", "Address");
        assertEquals(10, contact.getLastName().length(), "Last Name not trimmed properly.");
    }

    @Test
    @DisplayName("Phone number must be exactly 10 digits")
    void testPhoneNumberValidation() {
        Contact contact = new Contact("First", "Last", "123", "Address");
        assertEquals("5555555555", contact.getNumber(), "Invalid phone number accepted.");
    }

    @Test
    @DisplayName("Address should be trimmed to 30 characters")
    void testAddressTrimmed() {
        Contact contact = new Contact("First", "Last", "1234567890",
                "1234567890123456789012345678901234567890");
        assertEquals(30, contact.getAddress().length(), "Address not trimmed properly.");
    }

    @Test
    @DisplayName("First Name should not be null")
    void testFirstNameNotNull() {
        Contact contact = new Contact(null, "Last", "1234567890", "Address");
        assertNotNull(contact.getFirstName(), "First Name was null.");
    }

    @Test
    @DisplayName("Last Name should not be null")
    void testLastNameNotNull() {
        Contact contact = new Contact("First", null, "1234567890", "Address");
        assertNotNull(contact.getLastName(), "Last Name was null.");
    }

    @Test
    @DisplayName("Phone number should not be null")
    void testPhoneNotNull() {
        Contact contact = new Contact("First", "Last", null, "Address");
        assertNotNull(contact.getNumber(), "Phone number was null.");
    }

    @Test
    @DisplayName("Address should not be null")
    void testAddressNotNull() {
        Contact contact = new Contact("First", "Last", "1234567890", null);
        assertNotNull(contact.getAddress(), "Address was null.");
    }
}
